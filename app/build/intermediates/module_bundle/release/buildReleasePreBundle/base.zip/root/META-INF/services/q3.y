r3.b
